var hfc = require("../.."); 

var express = require('express'); 
var app = express(); 
var bodyParser = require('body-parser'); 

var PEER_ADDRESS         = process.env.CORE_PEER_ADDRESS; 
var MEMBERSRVC_ADDRESS   = process.env.MEMBERSRVC_ADDRESS; 

var chain, chaincodeID; 
var userObj ;
// Create a chain object used to interact with the chain. 
// You can name it anything you want as it is only used by client. 
chain = hfc.newChain("mychain"); 
// Initialize the place to store sensitive private key information 
chain.setKeyValStore( hfc.newFileKeyValStore('/tmp/keyValStore') ); 
// Set the URL to membership services and to the peer 
console.log("member services address ="+MEMBERSRVC_ADDRESS); 
console.log("peer address ="+PEER_ADDRESS); 
chain.setMemberServicesUrl("grpc://"+MEMBERSRVC_ADDRESS); 
chain.addPeer("grpc://"+PEER_ADDRESS); 

// The following is required when the peer is started in dev mode 
// (i.e. with the '--peer-chaincodedev' option) 
var mode =  process.env['DEPLOY_MODE']; 
console.log("DEPLOY_MODE=" + mode); 
if (mode === 'dev') { 
    chain.setDevMode(true); 
    //Deploy will not take long as the chain should already be running 
    chain.setDeployWaitTime(10); 
} else { 
    chain.setDevMode(false); 
    //Deploy will take much longer in network mode 
    chain.setDeployWaitTime(120); 
} 

chain.setInvokeWaitTime(10); 

function init(cb) {    
	
	 chain.enroll("admin", "Xurw3yU9zI0l", function(err, admin) { 
      if (err) { 
         console.log("ERROR: failed to register admin: %s",err); 
         process.exit(1); 
      } 
      // Set this user as the chain's registrar which is authorized to register other users. 
      chain.setRegistrar(admin); 

      var userName = "FirstUser"; 
      // registrationRequest 
      var registrationRequest = { 
          enrollmentID: userName, 
       };

      chain.registerAndEnroll(registrationRequest, function(error, user) { 
          if (error) throw Error(" Failed to register and enroll " + userName + ": " + error); 
          console.log("Enrolled %s successfully\n", userName); 
		}
		cb(null,user); 
 });
}


function updateAsset( args, user, cb) { 
   console.log("invoke chaincode ..."); 
   // Construct a query request 
   var invokeRequest = { 
      chaincodeID: chaincodeID, 
      fcn: "updateAsset", 
	  args: args
   }; 
   // Issue the invoke request and listen for events 
   var tx = user.Invoke(invokeRequest); 
   tx.on('submitted', function (results) { 
          console.log("invoke submitted successfully; results=%j",results); 
       }); 
   tx.on('complete', function (results) { 
      console.log("invoke completed successfully; results=%j",results); 
      cb(null,results); 
      //query(user); 
   }); 
   tx.on('error', function (error) { 
      console.log("Failed to invoke chaincode: request=%j, error=%k",invokeRequest,error); 
      process.exit(1); 
   }); 
} 


function getQuery(args , user, cb) { 
   console.log("querying chaincode ..."); 
   // Construct a query request 
   var queryRequest = { 
      chaincodeID: chaincodeID, 
      fcn: "getQuery", 
      args: [args] 
   }; 
   // Issue the query request and listen for events 
   var tx = user.Invoke(queryRequest); 
   tx.on('complete', function (results) { 
      console.log("query completed successfully; results=%j",results); 
      cb(null,results); 
      //process.exit(0); 
   }); 
   tx.on('error', function (error) { 
      console.log("Failed to query chaincode: request=%j, error=%k",queryRequest,error); 
      process.exit(1); 
   }); 
} 

function query(args, user, cb) { 
   console.log("querying chaincode ..."); 
   // Construct a query request 
   var queryRequest = { 
      chaincodeID: chaincodeID, 
      fcn: "query", 
      args: [args] 
   }; 
   // Issue the query request and listen for events 
   var tx = user.Query(queryRequest); 
   tx.on('complete', function (results) { 
      console.log("query completed successfully; results=%j",results); 
      cb(null,results); 
      //process.exit(0); 
   }); 
   tx.on('error', function (error) { 
      console.log("Failed to query chaincode: request=%j, error=%k",queryRequest,error); 
      process.exit(1); 
   }); 
} 

function deployChaincode(user,cb) {
    console.log(util.format("Deploying chaincode ... It will take about %j seconds to deploy \n", chain.getDeployWaitTime()))
  	
	 var deployRequest = {
        chaincodePath: "chaincode",
        fcn: "Init",
      };

    // Trigger the deploy transaction
    var deployTx = user.deploy(deployRequest);

    // Print the deploy results
   deployTx.on('complete', function(results) { 
       console.log("deploy complete; results: %j",results); 
       chaincodeID = results.chaincodeID; 
       cb(null,results); 
   }); 
   deployTx.on('error', function(error) { 
       console.log("Failed to deploy chaincode: request=%j, error=%k",deployRequest,error); 
       process.exit(1); 
   });
}

app.post("/process_deploy" , function(req , res) {
	   
	init(function(err,enrolleduser) { 
        if(err) { 
         console.log('***********Unknown Error'); 
         return; 
        }         
		deploy(enrolleduser ,function(err,results) { 
            if(err) { 
             console.log('***********Unknown Error'); 
             return; 
            } 
            console.log("********* chaincodeID return value from deploy : %s",results.chaincodeID); 
            // Prepare output in JSON format 
            response = { 
                chaincodeID:results.chaincodeID 
            }; 

            res.end(JSON.stringify(response)); 
        }); 
    }); 
})

app.post("/process_invoke" , function (req , res) {
	
	var body = req.body;
	var oper = body.operation;
	
	if(oper == 'updateAsset') {		
	trackDetails.push(body.order_id); 
	trackDetails.push(body.package_id) ;
	trackDetails.push(body.current_temp);
	trackDetails.push(body.time);
	trackDetails.push(body.max_temp);
	trackDetails.push(body._location);
	trackDetails.push(body._event);
	trackDetails.push(body.carrier);
		
		init(function(err,enrolleduser) { 
        if(err) { 
         console.log('*********** Error from enroll'); 
         return; 
        } 
        console.log("******* reponse from enroll %s", enrolleduser.name); 
		updateAsset(trackDetails,enrolleduser, function(err,results) { 
            if(err) { 
             console.log('***********Unknown Error'); 
             return; 
            } 
            console.log("********* return value from invoke : %s",results.result); 
            // Prepare output in JSON format 
            response = { 
                invokeresult:results.result 
            };
            res.end(JSON.stringify(response)); 
        }); 
    });
		
	} else if (oper == "getData") {
		
		init(function(err,enrolleduser) { 
        if(err) { 
         console.log('*********** Error from enroll'); 
         return; 
        } 
        console.log("******* reponse from enroll %s", enrolleduser.name); 
		getQuery(req.body.request_id,enrolleduser, function(err,results) { 
            if(err) { 
             console.log('***********Unknown Error'); 
             return; 
            } 
            console.log("********* return value from invoke : %s",results.result); 
            // Prepare output in JSON format 
            response = { 
                invokeresult:results.result 
            };
            res.end(JSON.stringify(response)); 
        }); 
      });
	}	
});

app.post("/process_query" , function (req , res) { 
      
	  init(function(err,enrolleduser) {		  
        if(err) { 
         console.log('*********** Error from enroll'); 
         return; 
        } 
        console.log("******* reponse from enroll %s", enrolleduser.name); 
        query(req.body.request_id , enrolleduser, function(err,results) { 
            if(err) { 
             console.log('***********Unknown Error'); 
             return; 
            } 
            console.log("********* return value from query : %s",results.result); 
            // Prepare output in JSON format 
            response = { 
                queryresult:results.result 
            }; 

            res.end(JSON.stringify(response)); 
        }); 
    });
});


var server = app.listen(8081, function () { 

   var host = server.address().address 
   var port = server.address().port 

   console.log("Example app listening at http://%s:%s", host, port) 
}) 
